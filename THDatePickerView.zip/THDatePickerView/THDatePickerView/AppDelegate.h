//
//  AppDelegate.h
//  THDatePickerView
//
//  Created by 希达 on 2018/4/26.
//  Copyright © 2018年 Tan.huang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

