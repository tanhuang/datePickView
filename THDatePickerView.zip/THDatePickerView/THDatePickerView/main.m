//
//  main.m
//  THDatePickerView
//
//  Created by 希达 on 2018/4/26.
//  Copyright © 2018年 Tan.huang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
